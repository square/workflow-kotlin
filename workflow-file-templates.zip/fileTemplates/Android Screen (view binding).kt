package ${PACKAGE_NAME}

import com.squareup.workflow1.ui.AndroidScreen
import com.squareup.workflow1.ui.ScreenViewFactory
import com.squareup.workflow1.ui.ScreenViewRunner
import com.squareup.workflow1.ui.ViewEnvironment

#parse("File Header.java")
data class $Name(
  // TODO: add properties needed to update $VIEW_BINDING_TYPE
) : AndroidScreen<$Name> {

  override val viewFactory =
    ScreenViewFactory.fromViewBinding($VIEW_BINDING_TYPE::inflate, ::${NAME.substring(0,1).toLowerCase()}${NAME.substring(1)}Runner)
}

private fun ${NAME.substring(0,1).toLowerCase()}${NAME.substring(1)}Runner(
  viewBinding: $VIEW_BINDING_TYPE
) = ScreenViewRunner { screen: ${Name}, environment: ViewEnvironment ->
  TODO("Update viewBinding from rendering")
}
