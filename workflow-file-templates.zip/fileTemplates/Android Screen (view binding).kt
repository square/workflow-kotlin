package ${PACKAGE_NAME}

import com.squareup.workflow1.ui.AndroidScreen
import com.squareup.workflow1.ui.ScreenViewFactory
import com.squareup.workflow1.ui.ScreenViewFactory.Companion.fromViewBinding
import com.squareup.workflow1.ui.ScreenViewRunner
import com.squareup.workflow1.ui.ViewEnvironment
import com.squareup.workflow1.ui.WorkflowUiExperimentalApi

#parse("File Header.java")
@OptIn(WorkflowUiExperimentalApi::class)
data class $Name(
  // TODO: add properties needed to update $VIEW_BINDING_TYPE
) : AndroidScreen<$Name> {

  override val viewFactory =
    ScreenViewFactory.fromViewBinding($VIEW_BINDING_TYPE::inflate, ::${Name}Runner)
}

@OptIn(WorkflowUiExperimentalApi::class)
private class ${Name}Runner(
  private val viewBinding: $VIEW_BINDING_TYPE
) : ScreenViewRunner<$Name> {

  override fun showRendering(
    rendering: $Name,
    environment: ViewEnvironment
  ) {
    TODO("Update viewBinding from rendering")
  }
}
 