package ${PACKAGE_NAME}

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.squareup.workflow1.ui.compose.ComposeScreen

#parse("File Header.java")
data class ${Name}(
  // TODO: add properties needed by ${Name}Content()
) : ComposeScreen {

  @Composable
  override fun Content() {
    ${Name}Content(this)
  }
}

@Composable
private fun ${Name}Content(
  screen: ${Name},
  modifier: Modifier = Modifier,
) {
  // TODO: write the code to display screen
}
